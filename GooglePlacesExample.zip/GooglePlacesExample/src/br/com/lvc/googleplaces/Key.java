package br.com.lvc.googleplaces;

public interface Key {

	//public static final String APP_KEY = "AIzaSyBaB9v2tIW4vGEYFvCp7itIa2uXBlWYHWE";
		public static final String WEB_APP_KEY = "AIzaSyC85eqg9HAMMUzMyjjt_MTUDMqzMWHWCd0";

}
