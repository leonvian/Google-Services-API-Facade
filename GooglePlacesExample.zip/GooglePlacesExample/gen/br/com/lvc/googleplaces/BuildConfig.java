/** Automatically generated file. DO NOT MODIFY */
package br.com.lvc.googleplaces;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}